const DatabaseWrapper = require('./db-wrapper.js');
const path = require('path');
const fs = require('fs');

// 数据库路径：navlink-next/data/sub.db
const projectRoot = path.join(__dirname, '..', '..', '..', '..');
const DB_PATH = path.join(projectRoot, 'data', 'sub.db');

let db = null;

/**
 * 获取数据库实例
 */
function getDatabase() {
    return db;
}

/**
 * 初始化数据库连接
 */
function initDatabase() {
    if (db) return db;

    // 确保data目录存在
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    // 创建数据库连接
    db = new DatabaseWrapper(DB_PATH);

    // 初始化表结构
    initSchema(db);

    console.log('[Database] SQLite initialized at:', DB_PATH);

    return db;
}

/**
 * 初始化表结构
 */
function initSchema(db) {
    // 订阅表
    db.exec(`
        CREATE TABLE IF NOT EXISTS subscriptions(
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL DEFAULT 'default',
    user_id TEXT NOT NULL DEFAULT 'default',
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    category TEXT DEFAULT '',
    price REAL DEFAULT 0,
    currency TEXT DEFAULT 'CNY',
    billingCycle TEXT DEFAULT 'monthly',
    expiryDate TEXT NOT NULL,
    reminderDays TEXT DEFAULT '7,3,1',
    isActive INTEGER DEFAULT 1,
    notes TEXT DEFAULT '',
    tags TEXT DEFAULT '',
    createdAt TEXT,
    updatedAt TEXT
);

--自定义提醒表
        CREATE TABLE IF NOT EXISTS custom_reminders(
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL DEFAULT 'default',
    user_id TEXT NOT NULL DEFAULT 'default',
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    targetDate TEXT NOT NULL,
    reminderDays TEXT DEFAULT '7,3,1',
    isActive INTEGER DEFAULT 1,
    category TEXT DEFAULT '',
    createdAt TEXT,
    updatedAt TEXT
);

--通知设置表
        CREATE TABLE IF NOT EXISTS notification_settings(
    id INTEGER PRIMARY KEY CHECK(id = 1),
    settings TEXT NOT NULL,
    updatedAt TEXT
);

--创建索引
        CREATE INDEX IF NOT EXISTS idx_subscriptions_tenant ON subscriptions(tenant_id, user_id);
        CREATE INDEX IF NOT EXISTS idx_subscriptions_expiry ON subscriptions(expiryDate);
        CREATE INDEX IF NOT EXISTS idx_subscriptions_active ON subscriptions(isActive);
        CREATE INDEX IF NOT EXISTS idx_reminders_tenant ON custom_reminders(tenant_id, user_id);
        CREATE INDEX IF NOT EXISTS idx_reminders_date ON custom_reminders(targetDate);
        CREATE INDEX IF NOT EXISTS idx_reminders_active ON custom_reminders(isActive);
`, (err) => {
        if (err) {
            console.error('[Database] Failed to initialize schema:', err);
        } else {
            // 添加reminderTime字段（如果不存在）
            db.exec(`
                -- 添加reminderTime字段到custom_reminders表
                ALTER TABLE custom_reminders ADD COLUMN reminderTime TEXT DEFAULT '09:00';
            `, (err) => {
                if (err && !err.message.includes('duplicate column')) {
                    console.error('[Database] Failed to add reminderTime column:', err);
                } else {
                    console.log('[Database] reminderTime column migration completed');

                    // 添加notified字段（如果不存在）
                    db.exec(`
                        -- 添加notified字段到custom_reminders表
                        ALTER TABLE custom_reminders ADD COLUMN notified INTEGER DEFAULT 0;
                    `, (err) => {
                        if (err && !err.message.includes('duplicate column')) {
                            console.error('[Database] Failed to add notified column:', err);
                        } else {
                            console.log('[Database] Schema migration completed');
                        }
                    });
                }
            });
        }
    });
}

module.exports = {
    initDatabase,
    getDatabase
};
